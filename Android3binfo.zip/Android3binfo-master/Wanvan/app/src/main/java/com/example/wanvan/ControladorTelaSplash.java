package com.example.wanvan;

import android.annotation.SuppressLint;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;

import java.util.Timer;
import java.util.TimerTask;


public class ControladorTelaSplash extends AppCompatActivity {

    private static final int TEMṔO = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.TelaSplash);
        iniciarTelaSplash();
    }

    private void iniciarTelaSplash() {
        new Timer().schedule((new TimerTask() {
            @Override
            public void run() {
                finish();
                Intent splash = new Intent();
                splash.setClass(ControladorTelaSplash.this,
                        ControladorTelaLogin.class);
                startActivity(splash);

            }
        }), TEMṔO);

        }
    }
