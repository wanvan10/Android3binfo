package com.example.wanvan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ControladorTelaConsulta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_consulta);
    }
}
